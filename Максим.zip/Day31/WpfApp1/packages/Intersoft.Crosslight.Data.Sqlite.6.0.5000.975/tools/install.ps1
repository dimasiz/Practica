param($installPath, $toolsPath, $package, $project)

$enableLog = $False

if ($enableLog)
{
    Write-Warning ("Install Path : " + $installPath)
    Write-Warning ("Tools Path : " + $toolsPath)
    Write-Warning ("Project : " + $project.Name)
    Write-Warning ("Project File Name: " + $project.FileName)    
    Write-Warning ("Package: " + $package.Id)
    Write-Warning ("Package: " + $package.Name)
}

# Save project file before run script
$project.Save()

$sqliteWinPhoneExtensionId = "SQLite.WP80";
$sqliteWinPhoneExtensionName = "SQLite for Windows Phone";
$sqliteWinPhoneExtensionVersion = "3.10.2";

$sqliteWinRTExtensionId = "SQLite.WinRT81";
$sqliteWinRTExtensionName = "SQLite for Windows Runtime %28Windows 8.1%29";
$sqliteWinRTExtensionVersion = "3.10.2";

$registryRoot = $DTE.RegistryRoot
$packageId = $package.Id
$packageVersion = $package.Version
$projectPath = $project.FileName
$libPath = [System.IO.Path]::Combine($toolsPath, "NugetUtil.dll")

if ($enableLog)
{
    Write-Warning ("NugetUtil Path : " + $libPath)
}

# Load helper
[System.Reflection.Assembly]::LoadFile($libPath) | Out-Null
$isWinPhoneProject = [NugetUtil.ProjectHelper]::IsWinPhoneProject($projectPath)
$isWinRTProject = [NugetUtil.ProjectHelper]::IsWinRTProject($projectPath)

if ($isWinPhoneProject)
{	
	# Add SDK Reference to Windows Phone project
	$sqliteWinPhoneExtensionVersion = [NugetUtil.SQLiteExtensionHelper]::GetExistingVersion($registryRoot, $sqliteWinPhoneExtensionId, $sqliteWinPhoneExtensionVersion)
	[NugetUtil.ProjectHelper]::AddSDKReference($packageId, $packageVersion, $projectPath, $sqliteWinPhoneExtensionId + ", Version=" + $sqliteWinPhoneExtensionVersion, $sqliteWinPhoneExtensionName)
}

if ($isWinRTProject)
{
	# Add SDK Reference to Windows Runtime project
	$sqliteWinRTExtensionVersion = [NugetUtil.SQLiteExtensionHelper]::GetExistingVersion($registryRoot, $sqliteWinRTExtensionId, $sqliteWinRTExtensionVersion)
	[NugetUtil.ProjectHelper]::AddSDKReference($packageId, $packageVersion, $projectPath, $sqliteWinRTExtensionId + ", Version=" + $sqliteWinRTExtensionVersion, $sqliteWinRTExtensionName)
}